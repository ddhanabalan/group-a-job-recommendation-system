import SignUpForm from "../../components/SignUpForm/SignUpForm";
import '../pages.css';

export default function SignUpPage(){
    return (
        <div id="page">
            <SignUpForm/>
        </div>
    )
}