import SignUpForm2 from "../../components/SignUpForm/SignUpForm2";
import '../pages.css';


export default function SignUpPage2(){
    return (
        <div id="page">
            <SignUpForm2/>
        </div>
    )
}