import '../pages.css';
import RedirectToRole from '../../components/RedirectToRole/RedirectToRole';
export default function LandingPage() {
    return (
        <div id="page">
            <RedirectToRole/>
        </div>
    )
}